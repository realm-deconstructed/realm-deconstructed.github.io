# Realm Deconstructed website

Public GitHub Pages website. Upload the files in this folder to the repository root on main and enable Pages from main / (root).

The progress figures are historical baselines, not live telemetry. Only aggregate recovery counts are included. No original game assets.

The publishing workflow from the private extraction repository is not yet connected.
